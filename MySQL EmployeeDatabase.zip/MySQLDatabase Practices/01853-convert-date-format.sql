-- date format

select date_format(day, '%W, %M %e, %Y') as day
from Days

-- no companies listed
