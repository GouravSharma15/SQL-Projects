-- simple WHERE clause

select customer_id
from Customers
where year = '2021' and revenue > 0


-- google- 1
