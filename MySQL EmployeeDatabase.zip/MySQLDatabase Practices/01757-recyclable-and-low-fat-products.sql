-- use WHERE for condition

select product_id
from Products
where low_fats = 'Y' and recyclable = 'Y'


-- amazon- 19
-- adobe- 10
-- google- 8
-- facebook- 3
-- apple- 3
-- microsoft- 3
-- yahoo- 2
-- bloomberg- 2



