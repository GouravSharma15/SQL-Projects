-- use of order by for sorting and break ties

select *
from Olympic
order by gold_medals desc, silver_medals desc, bronze_medals desc, country


-- no companies listed
